import React, { Component } from 'react'

export default class First extends Component {
    constructor(props){
        super(props)
    
        this.state = {
             text:"hello world!"
        }
    }
     changingState =()=>{
        this.setState({
            text:"Changed"
        })
    }
    
    render() {    
      return (
            <div>
                <h1>changing state</h1>
        <h2>{this.state.text}</h2>
      <h3>this is props {this.props.name}</h3>
                <button onClick={this.changingState}>hello</button>
            </div>
        )
    }
}


